# Kiroku (記録)

A privacy-first, self-hosted personal finance tracker built with a modern Go backend and Vue 3 frontend.

## Tech Stack

- **Backend:** Go 1.27+, Chi router (`go-chi/chi/v5`), SQLite (`modernc.org/sqlite`), Clean Architecture.
- **Frontend:** Vue 3 (Composition API with `<script setup lang="ts">`), Pinia, Vue Router, Tailwind CSS v4, TypeScript, Vite, PWA.

## Project Structure

- `backend/`: Go backend service (`cmd/server`, `internal/`)
- `frontend/`: Vue 3 SPA (`src/views`, `src/components`, `src/stores`, `src/locales`)
- `config/`: Process manager and runtime configurations

## Getting Started

### Prerequisites

- Go 1.27+
- Node.js & npm

### Development

Run backend and frontend concurrently:

```bash
# Backend (with live reload via Air or direct run)
cd backend && go run cmd/server/main.go

# Frontend
cd frontend && npm run dev
```

### Testing

```bash
# Backend tests
cd backend && go test ./...

# Frontend tests
cd frontend && npm run test:run
```

### Production Build

```bash
# Backend build (binary hard constraint: backend/bin/server)
cd backend && CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o bin/server cmd/server/main.go

# Frontend build
cd frontend && npm run build
```

## License

MIT
