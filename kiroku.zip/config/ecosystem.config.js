module.exports = {
  apps: [
    {
      name: "kiroku-backend",
      cwd: process.env.PROJECT_ROOT + "/backend",
      script: "/data/data/com.termux/files/home/go/bin/air",
      interpreter: "none",
      watch: false,
      env: {
        PORT: "8080",
        HOST: "0.0.0.0",
        INSITU_ADDR: ":8080",
        INSITU_DATA_DIR: process.env.PROJECT_ROOT + "/backend/data",
        CGO_ENABLED: "0",
        UPSTASH_REDIS_REST_URL: process.env.UPSTASH_REDIS_REST_URL || "",
        UPSTASH_REDIS_REST_TOKEN: process.env.BACKEND_UPSTASH_REDIS_REST_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN || "",
        BACKEND_UPSTASH_REDIS_REST_TOKEN: process.env.BACKEND_UPSTASH_REDIS_REST_TOKEN || "",
        CLOUDFLARE_TUNNEL_ENABLED: "true",
        KIROKU_TUNNEL_ENABLED: "true"
      },
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      merge_logs: true,
      error_file: process.env.PROJECT_ROOT + "/backend/logs/backend-error.log",
      out_file: process.env.PROJECT_ROOT + "/backend/logs/backend-out.log"
    },
    {
      name: "kiroku-frontend",
      cwd: process.env.PROJECT_ROOT + "/frontend",
      script: "npm",
      args: "run dev -- --host 0.0.0.0 --port 5173",
      interpreter: "none",
      watch: false,
      env: {
        HOST: "0.0.0.0",
        PORT: "5173"
      },
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      merge_logs: true,
      error_file: process.env.PROJECT_ROOT + "/frontend/logs/frontend-error.log",
      out_file: process.env.PROJECT_ROOT + "/frontend/logs/frontend-out.log"
    }
  ]
};
