#!/usr/bin/env python3

import re
from pathlib import Path

ROOT = Path('./backend/internal')
EXCLUDED_PACKAGE = 'models'
STRUCT_PATTERN = re.compile(r'\btype\s+(\w+)\s+struct\s*\{')


def find_structs():
    results = []

    for file_path in ROOT.glob('**/*.go'):
        if EXCLUDED_PACKAGE in file_path.relative_to(ROOT).parts:
            continue

        try:
            source = file_path.read_text(encoding='utf-8')
        except (OSError, UnicodeDecodeError):
            continue

        for match in STRUCT_PATTERN.finditer(source):
            line = source.count('\n', 0, match.start()) + 1
            results.append((file_path, line, match.group(1)))

    return results


def main():
    results = find_structs()

    if not results:
        print('No structs found outside the models package.')
        return

    for file_path, line, name in results:
        print(f'{file_path}:{line}: {name}')

    print(f'\nTotal: {len(results)} struct(s)')


if __name__ == '__main__':
    main()