package db

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"kiroku/backend/internal/config"
)

func testConfig(t *testing.T) *config.Config {
	t.Helper()
	return &config.Config{
		DataDir: t.TempDir(),
		DBPath:  "test.db",
	}
}

func TestMigration013_FreshDB(t *testing.T) {
	cfg := testConfig(t)
	db, err := Open(cfg)
	require.NoError(t, err)
	defer db.Close()

	exists, err := db.columnExists("users", "pin_hash")
	require.NoError(t, err)
	assert.True(t, exists)

	var version int
	require.NoError(t, db.QueryRow("SELECT MAX(version) FROM schema_version").Scan(&version))
	assert.Equal(t, 14, version)
}

func TestMigration013_PartiallyMigratedDB(t *testing.T) {
	cfg := testConfig(t)
	db, err := Open(cfg)
	require.NoError(t, err)

	_, err = db.Exec("DELETE FROM schema_version WHERE version = 13")
	require.NoError(t, err)
	require.NoError(t, db.Close())

	db2, err := Open(cfg)
	require.NoError(t, err)
	defer db2.Close()

	var version int
	require.NoError(t, db2.QueryRow("SELECT MAX(version) FROM schema_version").Scan(&version))
	assert.Equal(t, 14, version)
}
