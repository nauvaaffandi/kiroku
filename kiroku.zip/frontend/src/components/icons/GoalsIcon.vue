<template>
  <Target class="lucide-icon" />
</template>
<script setup lang="ts">
import { Target } from '@lucide/vue'
</script>
<style scoped>
.lucide-icon {
  width: 1.25em;
  height: 1.25em;
  flex-shrink: 0;
  display: inline-block;
  color: currentColor;
  vertical-align: middle;
}
</style>
