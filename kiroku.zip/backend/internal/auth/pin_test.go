package auth

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestDefaultPinVerification(t *testing.T) {
	hash, err := HashPin("123456", 3, 65536, 4)
	require.NoError(t, err)

	ok, err := VerifyPin("123456", hash)
	require.NoError(t, err)
	assert.True(t, ok, "default pin should verify correctly")
}

func TestVerifyPin_WrongPin(t *testing.T) {
	hash, err := HashPin("123456", 3, 65536, 4)
	require.NoError(t, err)

	ok, err := VerifyPin("wrongpin", hash)
	require.NoError(t, err)
	assert.False(t, ok, "wrong pin should not verify")
}

func TestVerifyPin_InvalidHash(t *testing.T) {
	ok, err := VerifyPin("123456", "invalid-hash")
	assert.Error(t, err)
	assert.False(t, ok)
}

func TestValidatePIN_Valid(t *testing.T) {
	require.NoError(t, ValidatePIN("123456"))
	require.NoError(t, ValidatePIN("000000"))
	require.NoError(t, ValidatePIN("999999"))
}

func TestValidatePIN_InvalidLength(t *testing.T) {
	require.Error(t, ValidatePIN("12345"))
	require.Error(t, ValidatePIN("1234567"))
	require.Error(t, ValidatePIN(""))
}

func TestValidatePIN_NonNumeric(t *testing.T) {
	require.Error(t, ValidatePIN("abcdef"))
	require.Error(t, ValidatePIN("12345a"))
	require.Error(t, ValidatePIN("12 456"))
}
