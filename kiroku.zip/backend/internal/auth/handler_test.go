package auth

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"kiroku/backend/internal/config"
	"kiroku/backend/internal/db"
)

func setupTestHandler(t *testing.T) (*Handler, *config.Config) {
	t.Helper()
	cfg := &config.Config{
		DataDir:        t.TempDir(),
		DBPath:         "test.db",
		JWTSecret:      "test-secret-key-32-bytes-long!!!!!",
		JWTAccessTTL:   15 * time.Minute,
		JWTRefreshTTL:  24 * time.Hour,
		Argon2Time:     1,
		Argon2Memory:   65536,
		Argon2Threads:  2,
	}

	database, err := db.Open(cfg)
	require.NoError(t, err)
	t.Cleanup(func() { database.Close() })

	h := NewHandler(database, cfg, nil)
	return h, cfg
}

func TestAuthFlow_LoginAndMe(t *testing.T) {
	h, _ := setupTestHandler(t)
	router := h.Routes()

	// 1. Unauthenticated GET /me should return 401
	req := httptest.NewRequest(http.MethodGet, "/me", nil)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusUnauthorized, rec.Code)

	// 2. Successful login with default PIN "123456"
	loginBody, _ := json.Marshal(map[string]string{"pin": "123456"})
	req = httptest.NewRequest(http.MethodPost, "/login", bytes.NewReader(loginBody))
	req.Header.Set("Content-Type", "application/json")
	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusOK, rec.Code)

	// Extract access_token cookie
	cookies := rec.Result().Cookies()
	var accessCookie *http.Cookie
	for _, c := range cookies {
		if c.Name == "access_token" {
			accessCookie = c
			break
		}
	}
	require.NotNil(t, accessCookie, "access_token cookie should be set")

	// 3. Authenticated GET /me using cookie should return 200 with user_id
	req = httptest.NewRequest(http.MethodGet, "/me", nil)
	req.AddCookie(accessCookie)
	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusOK, rec.Code)

	var meResp map[string]string
	err := json.NewDecoder(rec.Body).Decode(&meResp)
	require.NoError(t, err)
	assert.NotEmpty(t, meResp["user_id"])

	// 4. Authenticated GET /me using Authorization: Bearer header should also return 200
	req = httptest.NewRequest(http.MethodGet, "/me", nil)
	req.Header.Set("Authorization", "Bearer "+accessCookie.Value)
	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusOK, rec.Code)

	var meBearerResp map[string]string
	err = json.NewDecoder(rec.Body).Decode(&meBearerResp)
	require.NoError(t, err)
	assert.Equal(t, meResp["user_id"], meBearerResp["user_id"])

	// 5. POST /logout should clear cookies
	req = httptest.NewRequest(http.MethodPost, "/logout", nil)
	rec = httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	assert.Equal(t, http.StatusOK, rec.Code)
}
